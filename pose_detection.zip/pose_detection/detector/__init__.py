# detector/__init__.py

from .pose_detector import DetectorPostura
